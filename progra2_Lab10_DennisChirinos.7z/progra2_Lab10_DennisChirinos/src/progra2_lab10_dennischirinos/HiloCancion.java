/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progra2_lab10_dennischirinos;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JProgressBar;

/**
 *
 * @author denni
 */
public class HiloCancion implements Runnable {

    int Duracion;

    String N;
    String A;
    JLabel Tiempo;
    JLabel Nombre;
    JLabel Artista;
    JProgressBar Barra;
    public HiloCancion(int Duracion, String N, String A, JLabel Tiempo, JLabel Nombre, JLabel Artista, JProgressBar Barra) {
        this.Duracion = Duracion;
        this.N = N;
        this.A = A;
        this.Tiempo = Tiempo;
        this.Nombre = Nombre;
        this.Artista = Artista;
        this.Barra = Barra;
    }

    

    @Override

    public void run() {
        int t = Duracion;
        Barra.setMaximum(Duracion);
        while (t >= 0) {
            int horas;
            int minutos;
            int segundos;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(HiloCancion.class.getName()).log(Level.SEVERE, null, ex);
            }
            t--;
            this.Tiempo.setText(t + "");
            this.Nombre.setText(N);
            this.Artista.setText(A);
            Barra.setValue(Duracion-t);
        }
        
        
    }

}
