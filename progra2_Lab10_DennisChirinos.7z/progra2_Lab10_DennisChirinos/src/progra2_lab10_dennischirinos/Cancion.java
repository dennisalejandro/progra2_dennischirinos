/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progra2_lab10_dennischirinos;

import java.io.Serializable;
import java.sql.Time;
import java.util.Calendar;

/**
 *
 * @author denni
 */
public class Cancion implements Serializable{
    String Nombre;
    String Artista;
    String Playlist;
    String Album;
    String Favorito;
    int Duracion;

    public Cancion(String Nombre, String Artista, String Playlist, String Album, String Favorito, int Duracion) {
        this.Nombre = Nombre;
        this.Artista = Artista;
        this.Playlist = Playlist;
        this.Album = Album;
        this.Favorito = Favorito;
        this.Duracion = Duracion;
    }

    public String getFavorito() {
        return Favorito;
    }

    public void setFavorito(String Favorito) {
        this.Favorito = Favorito;
    }

    

    public String getAlbum() {
        return Album;
    }

    public void setAlbum(String Album) {
        this.Album = Album;
    }
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getArtista() {
        return Artista;
    }

    public void setArtista(String Artista) {
        this.Artista = Artista;
    }

    public String getPlaylist() {
        return Playlist;
    }

    public void setPlaylist(String Playlist) {
        this.Playlist = Playlist;
    }

    public int getDuracion() {
        return Duracion;
    }

    public void setDuracion(int Duracion) {
        this.Duracion = Duracion;
    }

    @Override
    public String toString() {
        return Nombre;
    }
    
    

}