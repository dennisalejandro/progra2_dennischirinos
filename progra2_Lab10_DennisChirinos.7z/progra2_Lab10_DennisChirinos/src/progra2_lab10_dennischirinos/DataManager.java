/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progra2_lab10_dennischirinos;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 *
 * @author denni
 */
public class DataManager {

    FileOutputStream FOS;
    ObjectOutputStream OOS;
    FileInputStream FIS;
    ObjectInputStream OIS;
    File DataUsuarios = null;
    File DataCanciones = null;
    File DataAlbumes = null;
    ArrayList<Usuario> listaUsuarios = new ArrayList<>();
    ArrayList<Cancion> listaCanciones = new ArrayList<>();
    ArrayList<Album> listaAlbumes = new ArrayList<>();

    public DataManager() {
    DataUsuarios = new File("./Usuarios.txt");
    DataCanciones = new File("./Canciones.txt");
    DataAlbumes = new File("./Albumes.txt");
    }

    public void SaveUsuarios() {
        try {
            File temp = DataUsuarios;
            FOS = new FileOutputStream(temp);
            OOS = new ObjectOutputStream(FOS);
            ArrayList<Usuario> U = listaUsuarios;
            for (int i = 0; i < U.size(); i++) {
                OOS.writeObject(U.get(i));
            }
            OOS.flush();
            OOS.close();
            FOS.close();
        } catch (IOException ex) {

        }

    }
    public void LoadUsuarios() {
        try {
            File ArchivoOut = DataUsuarios;
            FIS = new FileInputStream(ArchivoOut);
            OIS = new ObjectInputStream(FIS);
            Usuario temp;
            try {

                while ((temp = (Usuario) OIS.readObject()) != null) {
                    listaUsuarios.add(temp);
                }
            } catch (EOFException e) {
                System.out.println("Termino");
                System.out.println(e.getMessage());
            }
            System.out.println("Señal");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void SaveCanciones() {
        try {
            File temp = DataCanciones;
            FOS = new FileOutputStream(temp);
            OOS = new ObjectOutputStream(FOS);
            ArrayList<Cancion> U = listaCanciones;
            for (int i = 0; i < U.size(); i++) {
                OOS.writeObject(U.get(i));
            }
            OOS.flush();
            OOS.close();
            FOS.close();
        } catch (IOException ex) {

        }

    }
    public void LoadCanciones() {
        try {
            File ArchivoOut = DataCanciones;
            FIS = new FileInputStream(ArchivoOut);
            OIS = new ObjectInputStream(FIS);
            Cancion temp;
            try {

                while ((temp = (Cancion) OIS.readObject()) != null) {
                    listaCanciones.add(temp);
                }
            } catch (EOFException e) {
                System.out.println("Termino");
                System.out.println(e.getMessage());
            }
            System.out.println("Señal");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void SaveAlbumes() {
        try {
            File temp = DataAlbumes;
            FOS = new FileOutputStream(temp);
            OOS = new ObjectOutputStream(FOS);
            ArrayList<Album> U = listaAlbumes;
            for (int i = 0; i < U.size(); i++) {
                OOS.writeObject(U.get(i));
            }
            OOS.flush();
            OOS.close();
            FOS.close();
        } catch (IOException ex) {

        }

    }
    public void LoadAlbumes() {
        try {
            File ArchivoOut = DataAlbumes;
            FIS = new FileInputStream(ArchivoOut);
            OIS = new ObjectInputStream(FIS);
            Album temp;
            try {
                while ((temp = (Album) OIS.readObject()) != null) {
                    listaAlbumes.add(temp);
                }
            } catch (EOFException e) {
                System.out.println("Termino");
                System.out.println(e.getMessage());
            }
            System.out.println("Señal");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
