/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progra2_lab10_dennischirinos;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author denni
 */
public class Album implements Serializable{
    String Nombre;
    String Artista;
    ArrayList<Cancion> listaCancion = new ArrayList();

    public Album(String Nombre, String Artista) {
        this.Nombre = Nombre;
        this.Artista = Artista;
        
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getArtista() {
        return Artista;
    }

    public void setArtista(String Artista) {
        this.Artista = Artista;
    }

    public ArrayList<Cancion> getListaCancion() {
        return listaCancion;
    }

    public void setListaCancion(ArrayList<Cancion> listaCancion) {
        this.listaCancion = listaCancion;
    }

    @Override
    public String toString() {
        return Nombre;
    }
    
    
}
